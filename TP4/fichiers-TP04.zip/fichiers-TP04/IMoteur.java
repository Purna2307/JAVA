/**
 * L'interface <b>IMoteur</b> est impl&eacute;ment&eacute;e par la classe
 *   <b>Moteur</b>
 * @author Cyril Rabat
 * @author Jessica Jonquet
 * @version 06/02/2023
 */
public interface IMoteur {

    /**
     * Retourne la carburation du moteur
     * @return la carburation
     */
    public String getCarburation();

    /**
     * Retourne la consommation du moteur en L/100km
     * @return la consommation
     */
    public double getConsommation();

    /**
     * Affiche le moteur &agrave; l'&eacute;cran
     */
    public void afficher();

    /**
     * Retourne un moteur sous forme de chaine de caract&egrave;res
     * @return une chaine de caract&egrave;res
     */
    public String toString();

}

